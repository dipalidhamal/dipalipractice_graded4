package com.app.EmployeeJooq;

public class EmployeeJooqApplicationTest {

	public static void main(String[] args) {
		EmployeeJooqApplication.main(new String[] {"--spring.profiles.active=local"});
	}

}
