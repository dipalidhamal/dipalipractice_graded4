
package backEnd;

public class Department {
String DeptName;    

    public Department(String DeptName) {
        this.DeptName = DeptName;
    }
    
    public void setDeptName(String DeptName) {
        this.DeptName = DeptName;
    }

    public String getDeptName() {
        return DeptName;
    }
    
}
