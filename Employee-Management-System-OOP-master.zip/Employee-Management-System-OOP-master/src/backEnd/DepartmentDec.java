package backEnd;

public class DepartmentDec {

    public Department HR = new Department("HR");
    public Department Finance = new Department("Finance");
    public Department Technical = new Department("Technical");
    public Department Marketing = new Department("Marketing");
    public Designation CEO = new Designation("CEO");
    public Designation Manager = new Designation("Manager");
    public Designation Staff = new Designation("Staff");

}
