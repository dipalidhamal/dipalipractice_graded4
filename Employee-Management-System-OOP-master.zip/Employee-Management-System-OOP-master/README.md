
# Employee Management System

Disclaimer: This was a Basic Entry Level Project, based on Java, which I worked on in my Second Semester in Bahria University Karachi Campus.

This Project includes:
- Application of Basic Concepts of OOP
- Microsoft Access Database


This System is used to store information and monitor different activities of Employees in a 
company.

This System allows us to manage the employee data and track the 
employees. 


Note: Netbeans IDE is required to run the contents of this Project.

For Further Details About the Project, Please Refer to the Project Report File Attached.